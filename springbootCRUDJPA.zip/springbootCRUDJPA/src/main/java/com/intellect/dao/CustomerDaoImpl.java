package com.intellect.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intellect.model.Customer;
import com.intellect.repository.CustomerRespository;
import com.intellect.repository.UserRepository;

@Service
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	CustomerRespository customerRespository;
	
	@Autowired
	UserRepository userRepository;
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		
		List<Customer>  list = customerRespository.findAll();
		return null;
	}
	
	
	

}
