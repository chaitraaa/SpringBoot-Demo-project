package com.intellect.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.intellect.model.Customer;

@Service
public interface CustomerDao {
	
	public List<Customer> getAllCustomers();

}
